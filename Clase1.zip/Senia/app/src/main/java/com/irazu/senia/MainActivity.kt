package com.irazu.senia

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle

import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    val charPool : List<Char> = ('a'..'z') + ('A'..'Z') + ('0'..'9')

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvMensaje.setText("Maya")

        btnGenerar.setOnClickListener{
            var pswd=RandomString.generar(charPool,8)
            tvMensaje.setText("Hola Mundo")
        }
        if(savedInstanceState != null){
            var tmp=savedInstanceState.getString(MENSAJE)
            tvMensaje.setText(tmp)
        }
    }

    override fun onSaveInstanceState(outState: Bundle?) {
        outState?.run{
            var tmp=tvMensaje.text.toString()
            putString(MENSAJE,tmp)
        }
        super.onSaveInstanceState(outState)

    }
companion object{
    val MENSAJE ="mensaje"
}
}

